const fs = require('fs');
const slotDataFile = './slots.json';
let slotData = {};
function loadSlotData() {
    try {
        const data = fs.readFileSync(slotDataFile, 'utf8');
        slotData = JSON.parse(data);
    } catch (error) {
        slotData = {}; 
    }
}

function saveSlotData() {
    fs.writeFileSync(slotDataFile, JSON.stringify(slotData, null, 2));
}

module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        try {
            if (message.mentions.everyone) {
                loadSlotData();
                const userSlotData = slotData[message.author.id];
                if (userSlotData) {
                    const channelId = userSlotData.channelid;
                    if (message.channel.id === channelId) {
                        const now = new Date();
                        const startOfDay = new Date(now);
                        startOfDay.setHours(0, 0, 0, 0);

                        if (new Date(userSlotData.lastReset) < startOfDay) {
                            userSlotData.pingsused = 0;
                            userSlotData.lastreset = new Date().toISOString();
                        }

                        userSlotData.pingsused++;

                        slotData[message.author.id] = userSlotData;
                        saveSlotData();

                        const pingsRemaining = userSlotData.pinglimit - userSlotData.pingsused;
                        const guild = message.guild;

                        if (pingsRemaining >= 0) {
                            await message.reply(`${message.author}, you have ${pingsRemaining} ping(s) remaining.`);
                        } else {
                            await message.reply(`${message.author}, your slot has been revoked due to exceeding the ping limit.`);

                            const member = await guild.members.fetch(message.author.id);
                            const role = guild.roles.cache.get(userSlotData.roleid);
                            if (member && role) {
                                await member.roles.remove(role).catch(console.error);
                            }
                            if (channelId) {
                                try {
                                    const channel = await guild.channels.fetch(channelId);
                                    if (channel) {
                                        await channel.permissionOverwrites.delete(message.author.id); 
                                    }
                                } catch (error) {
                                    console.error('Error removing user permission from channel:', error);
                                }
                            }
                            saveSlotData();
                        }
                    }
                }
            }
        } catch (error) { 
            console.error("Error in messageCreate:", error);
        } 
    }, 
    loadSlotData, 
    saveSlotData 
}; 
const now = new Date();
const hours = String(now.getHours()).padStart(2, '0'); 
const minutes = String(now.getMinutes()).padStart(2, '0');
const seconds = String(now.getSeconds()).padStart(2, '0');

global.timestamp = `${hours}:${minutes}:${seconds}`; 

module.exports = {
    name: "ready",
    once: true,
    async execute(client) {
        console.log(`${global.timestamp} | Connected to ${client.user.username}.`);
        setInterval(() => {
            const activities = [
                {
                    name: "ƬψƦ Gen",
                    type: 3,
                },
                {
                    name: "Hosted by nd2006_",
                    type: 0,
                },
                {
                    name: "Skidded from Slot Bot 2.0 by Heis",
                    type: 0,
                }
            ];
            const customActivities = Math.floor(
                Math.random() * activities.length
            );

            client.user.setActivity(`${activities[customActivities].name}`, {
                type: activities[customActivities].type,
                status: "online",
            });
        }, 2000); 

    },
};

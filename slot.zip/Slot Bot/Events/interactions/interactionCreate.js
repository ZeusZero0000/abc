    module.exports = {
    name: "interactionCreate",

    async execute(interaction, client) {

        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) {
                return interaction.reply({ content: "outdated command" });
            }

            await command.execute(interaction, client);
        }
    },
};

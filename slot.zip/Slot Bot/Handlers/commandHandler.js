const fs = require("fs");

function loadCommands(client) {
    let commandsArray = [];

    const commandsFolder = fs.readdirSync("./Commands");
    for (const folder of commandsFolder) {
        const commandFiles = fs
            .readdirSync(`./Commands/${folder}`)
            .filter((file) => file.endsWith(".js"));

        for (const file of commandFiles) {
            // Correct path if running this file from a different location
            const commandFile = require(`../Commands/${folder}/${file}`);

            // Check if commandFile.data is defined
            if (!commandFile.data || !commandFile.data.name) {
                console.error(`Command file ${file} does not export a valid data object.`);
                continue;
            }

            const properties = { folder, ...commandFile };
            client.commands.set(commandFile.data.name, properties);

            commandsArray.push(commandFile.data.toJSON());
        }
    }

    client.application.commands.set(commandsArray);
    const loadedCommandsCount = commandsArray.length;

    return console.log(`${global.timestamp} | Loaded ${loadedCommandsCount} Commands`);
}

module.exports = { loadCommands };

const fs = require('fs');
const path = require('path');

const slotFilePath = path.join(__dirname, '../slots.json');

// Function to read slot data from slots.json
function readSlotData() {
  if (!fs.existsSync(slotFilePath)) {
    return {}; // Return an empty object if the file doesn't exist
  }
  const data = fs.readFileSync(slotFilePath, 'utf8');
  return JSON.parse(data);
}

// Function to write slot data to slots.json
function writeSlotData(slotData) {
  fs.writeFileSync(slotFilePath, JSON.stringify(slotData, null, 2), 'utf8');
}

module.exports = {
  readSlotData,
  writeSlotData,
};

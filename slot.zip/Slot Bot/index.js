const { Client, GatewayIntentBits, Partials, Collection, EmbedBuilder } = require("discord.js");
const { Guilds, GuildMembers, GuildMessages } = GatewayIntentBits;
const { User, Message, GuildMember, ThreadMember } = Partials;
const { loadEvents } = require("./Handlers/eventHandler");
const { loadCommands } = require("./Handlers/commandHandler");
const cron = require("node-cron");
const fs = require("fs");
const slotDataFile = "./slots.json";
const { token, guildid, channelid, sellerrole } = require("./config.json");

let slotData = {};

function loadSlotData() {
  try {
    const data = fs.readFileSync(slotDataFile, "utf8");
    slotData = JSON.parse(data);
  } catch (error) {
    console.error("Lỗi khi đọc dữ liệu slot:", error);
    slotData = {};
  }
}

function saveSlotData() {
  try {
    fs.writeFileSync(slotDataFile, JSON.stringify(slotData, null, 2));
  } catch (error) {
    console.error("Error ư", error);
  }
}

const client = new Client({
  intents: [Guilds, GuildMembers, GuildMessages],
  partials: [User, Message, GuildMember, ThreadMember],
});

process.title = "Slot Bot V1.2";
client.commands = new Collection();

loadSlotData();

client.login(token).then(() => {
  loadEvents(client);
  loadCommands(client);

  cron.schedule("0 0 * * *", async () => {
    loadSlotData();
  
    const now = new Date();
    const today = now.toLocaleDateString("en-GB");
  
    const guild = client.guilds.cache.get(guildid);
    const notificationChannel = guild?.channels.cache.get(channelid);
  
    if (!guild || !notificationChannel) {
      console.error("Guild hoặc channel không tìm thấy. Vui lòng kiểm tra lại guildid và channelid trong config.json.");
      return;
    }
  
    for (const userId in slotData) {
      const userSlotData = slotData[userId];
  
      if (userSlotData) {
        userSlotData.pingsused = 0;
        userSlotData.lastReset = new Date().toISOString();
  
        try {
          const user = await client.users.fetch(userId);
          await user.send("Ping của bạn đã được đặt lại!");
  
          const resetEmbed = new EmbedBuilder()
            .setTitle("Pings Reset Time")
            .setDescription("All Pings have been reset")
            .setColor(0x00ff00)
            .setTimestamp();
  
          await notificationChannel.send({ 
            content: `<@&${sellerrole}>`,
            embeds: [resetEmbed] 
          });
  
          if (userSlotData.expirydate === today) {
            const dmEmbed = new EmbedBuilder()
              .setTitle("Slot đã hết hạn")
              .setDescription("Vui lòng gia hạn, hãy liên hệ owner.")
              .setColor(0xff0000)
              .setTimestamp();
          
            try {
              await user.send({ embeds: [dmEmbed] });
            } catch (error) {
              if (error.code === 50007) {
                console.error(`Không thể gửi tin nhắn cho người dùng ${userId}: Họ đã tắt tin nhắn DM.`);
              } else {
                console.error(`Lỗi gửi tin nhắn cho ${userId}:`, error);
              }
            }
          
            const userGuild = client.guilds.cache.get(userSlotData.guildid);
            if (userGuild) {
              const userChannel = userGuild.channels.cache.get(userSlotData.channelid);
              if (userChannel) {
                try {
                  const member = await userGuild.members.fetch(userId);
                  await userChannel.permissionOverwrites.edit(member, {
                    SEND_MESSAGES: false,
                  });
          
                  const channelEmbed = new EmbedBuilder()
                    .setTitle("Slot đã hết hạn")
                    .setDescription(`<@${userId}>, slot của bạn đã hết hạn. Vui lòng gia hạn hoặc liên hệ owner.`)
                    .setColor(0xff0000)
                    .setTimestamp();
          
                  await userChannel.send({ embeds: [channelEmbed] });
                } catch (error) {
                  console.error(`Lỗi khi xử lý kênh hoặc quyền cho người dùng ${userId}:`, error);
                }
              } else {
                console.error(`Kênh không tìm thấy trong guild ${userSlotData.guildid}.`);
              }
            } else {
              console.error(`Guild không tìm thấy với ID ${userSlotData.guildid}.`);
            }
  
            const expireEmbed = new EmbedBuilder()
              .setTitle("Slot Expired")
              .setDescription(`<@${userId}>'s slot has expired.`)
              .setColor(0xff0000)
              .setTimestamp();
          
            try {
              await notificationChannel.send({ embeds: [expireEmbed] });
            } catch (error) {
              console.error(`Lỗi gửi thông báo hết hạn đến kênh:`, error);
            }
          }
        } catch (error) {
          console.error(`Lỗi xử lý slot cho người dùng ${userId}:`, error);
        }
      }
    }
  
    saveSlotData();
    console.log("Ping counts reset và kiểm tra hết hạn cho tất cả user đã hoàn tất!");
  });
});

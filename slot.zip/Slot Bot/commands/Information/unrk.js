const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../../config.json'); // Adjust the path if necessary

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unrk')
    .setDescription('Remove a user from the list of slots and allow them to chat again.')
    .addUserOption(option => 
      option.setName('user')
        .setDescription('The user to remove from the slot list')
        .setRequired(true)
    ),
  async execute(interaction) {
    const adminID = config.adminID;
    if (interaction.user.id !== adminID) {
      return interaction.reply("You do not have permission to use this command.");
    }

    const user = interaction.options.getUser('user');
    if (!user) {
      return interaction.reply("User not found.");
    }

    const slotFilePath = path.join(__dirname, '../../slots.json');
    let slotData;
    try {
      slotData = JSON.parse(fs.readFileSync(slotFilePath, 'utf-8'));
    } catch (error) {
      console.error('Failed to read or parse slots.json:', error);
      return interaction.reply("An error occurred while processing the request.");
    }

    if (!slotData[user.id]) {
      return interaction.reply("User does not have a slot.");
    }

    const userSlot = slotData[user.id];
    const channelId = userSlot.channelid;

    delete slotData[user.id];

    try {
      fs.writeFileSync(slotFilePath, JSON.stringify(slotData, null, 2));
    } catch (error) {
      console.error('Failed to write slots.json:', error);
      return interaction.reply("An error occurred while updating the slot list.");
    }

    const unrevokeEmbed = new EmbedBuilder()
      .setTitle("SLOT UNREVOKED!")
      .setDescription(`• ${user.tag} has been removed from the slot list and can now chat again.`)
      .setThumbnail('https://cdn.discordapp.com/emojis/1270746880959053854.gif?size=96&quality=lossless')
      .setColor(0x00ff00)
      .setFooter({ text: "Heiskso Slot Bot" })
      .setTimestamp();

    await interaction.reply({ embeds: [unrevokeEmbed] });

    try {
      await user.send({ embeds: [unrevokeEmbed] });
    } catch (error) {
      console.error(`Failed to send DM to ${user.tag}`);
    }

    if (channelId) {
      const channel = await interaction.guild.channels.fetch(channelId);
      if (channel) {
        await channel.permissionOverwrites.edit(user.id, {
          [PermissionsBitField.Flags.SendMessages]: true,
          [PermissionsBitField.Flags.AddReactions]: true
        }).catch(console.error);
      } else {
        console.log("Channel not found.");
      }
    }
  },
};

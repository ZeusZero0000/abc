const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Help Command Slot'),
    
    async execute(interaction) {
        const helpEmbed = new EmbedBuilder()
            .setTitle('Help')
            .setDescription('Welcome to the help command. Use the dropdown to select a category.')
            .setColor('#00ffcc');

        const row = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('select-category')
                .setPlaceholder('Select a category')
                .addOptions([
                    {
                        label: 'Slot Owner Commands',
                        description: 'Commands for slot owners',
                        value: 'slot_owner_commands',
                    },
                    {
                        label: 'Admin Commands',
                        description: 'Commands for admins',
                        value: 'admin_commands',
                    },
                ]),
        );

        await interaction.reply({ embeds: [helpEmbed], components: [row] });

        const filter = i => i.customId === 'select-category' && i.user.id === interaction.user.id;
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async i => {
            let embed;

            if (i.values[0] === 'slot_owner_commands') {
                embed = new EmbedBuilder()
                    .setTitle('Slot Owner Commands')
                    .setDescription('`/info (youruser)`: Shows your slot\n`/nuke (Number of messages)`: Cleans the channel')
                    .setColor('#00ffcc');
            } else if (i.values[0] === 'admin_commands') {
                embed = new EmbedBuilder()
                    .setTitle('Admin Commands')
                    .setDescription('`/slots`: Create a slot\n`/delete`: Delete a slot\n`/renew`: Renew a slot\n`/rk`: Revoke a slot\n`/unrk`: Unrevoke a slot\n`/hold`: Hold a slot\n`/unhold`: Unhold a slot\n`/reset`: Ping reset the slot')
                    .setColor('#ffcc00');
            }

            await i.update({ embeds: [embed], components: [] });
        });

        collector.on('end', collected => {
            if (!collected.size) {
                interaction.editReply({ content: 'Help session timed out', components: [] });
            }
        });
    },
};

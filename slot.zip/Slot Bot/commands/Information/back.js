const { Client, GatewayIntentBits, Events, Collection, EmbedBuilder, WebhookClient, ChannelType, SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../../config.json');

function calculateExpiryDate(duration) {
    const today = new Date();
    const vietnamTimezoneOffset = 7 * 60;
    const vietnamTime = new Date(today.getTime() + vietnamTimezoneOffset * 60 * 1000);

    if (duration === '1day') {
        vietnamTime.setDate(vietnamTime.getDate() + 1);
    } else if (duration === '7days') {
        vietnamTime.setDate(vietnamTime.getDate() + 7);
    } else if (duration === '30days') {
        vietnamTime.setMonth(vietnamTime.getMonth() + 1);
    } else if (duration === 'lifetime') {
        return 'Never';
    }

    return vietnamTime.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit' });
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('back')
        .setDescription('Backup slots from slots.json and recreate them.')
        .addChannelOption(option =>
            option.setName('category')
                .setDescription('The category where the slots should be created.')
                .addChannelTypes(ChannelType.GuildCategory)
                .setRequired(true)),
    async execute(interaction) {
        await interaction.reply({ content: 'Processing your request...', ephemeral: true });

        if (interaction.user.id !== config.adminID) {
            console.log(`${interaction.user.tag} (ID: ${interaction.user.id}) đã cố gắng sử dụng lệnh /back nhưng không có quyền.`);
            const webhookURL = config.webhookURL;
            const webhookClient = new WebhookClient({ url: webhookURL });
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('⚠️ Warning')
                .addFields(
                    { name: 'Tên', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'ID', value: interaction.user.id, inline: true },
                    { name: 'Lệnh', value: '/back', inline: true }
                )
                .setTimestamp();
            await webhookClient.send({
                username: 'Slot Bot Security',
                avatarURL: interaction.client.user.displayAvatarURL(),
                embeds: [embed]
            });
            return interaction.followUp({
                content: "`❌` Bạn không có quyền sử dụng lệnh này.",
                ephemeral: true
            });
        }

        const category = interaction.options.getChannel('category');

        if (!category || category.type !== ChannelType.GuildCategory) {
            return interaction.followUp({
                content: 'Vui lòng chọn một category hợp lệ.',
                ephemeral: true
            });
        }

        const filePath = path.join(__dirname, '../../slots.json');
        
        if (!fs.existsSync(filePath)) {
            return interaction.followUp({
                content: 'File slots.json không tồn tại.',
                ephemeral: true
            });
        }

        let slotsData;
        try {
            const data = fs.readFileSync(filePath, 'utf8');
            slotsData = JSON.parse(data);
        } catch (error) {
            console.error('Error reading slots.json:', error);
            return interaction.followUp({
                content: 'Đã xảy ra lỗi khi đọc tệp slots.json.',
                ephemeral: true
            });
        }

        for (const slotId in slotsData) {
            const slot = slotsData[slotId];
            
            let channel = interaction.guild.channels.cache.get(slot.channelid);
            if (!channel) {
                try {
                    const newChannel = await interaction.guild.channels.create({
                        name: `${interaction.user.username}-slot`,
                        type: ChannelType.GuildText,
                        topic: `Role ID: ${slot.roleid}, Expires: ${slot.expirydate}`,
                        parent: category.id
                    });
                    slot.channelid = newChannel.id;

                    const purchaseDate = new Date(new Date().getTime() + (7 * 60 * 60 * 1000)).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit' });
                    const expiryDate = calculateExpiryDate(slot.duration);
                    const slotType = slot.duration === '1day' || slot.duration === '7days' ? 'Day Slot' :
                        slot.duration === '30days' ? 'Month Slot' :
                        slot.duration === 'lifetime' ? 'Lifetime Slot' : 'Unknown Slot';
                    const formattedDuration = slot.duration
                        .replace('day', ' Day ')
                        .replace('days', ' Days');
                    await newChannel.send(`<@${interaction.user.id}>`);
                    const embed = new EmbedBuilder()
                        .setColor('Random')
                        .setTitle(slotType)
                        .setDescription(
                            `Purchase date: ${purchaseDate}\n` +
                            `Duration: **${formattedDuration}**\n` +
                            `Expiry date: ${expiryDate}\n\n` +
                            '**Permissions**\n' +
                            '```\n' + `${slot.pinglimit.toString()}x @everyone pings` + '\n```\n'
                        )
                        .setFooter({ text: 'You must follow the slot rules strictly' })
                        .setThumbnail(interaction.user.displayAvatarURL());
                    await newChannel.send({ embeds: [embed] });
                } catch (error) {
                    console.error('Error creating channel:', error);
                    return interaction.followUp({
                        content: `Đã xảy ra lỗi khi tạo kênh cho slot: ${slotId}`,
                        ephemeral: true
                    });
                }
            }
        }

        try {
            fs.writeFileSync(filePath, JSON.stringify(slotsData, null, 4), 'utf8');
        } catch (error) {
            console.error('Error writing to slots.json:', error);
            return interaction.followUp({
                content: 'Đã xảy ra lỗi khi lưu tệp slots.json.',
                ephemeral: true
            });
        }

        return interaction.followUp({
            content: 'Đã backup và tạo lại các slot thành công.',
            ephemeral: true
        });
    },
};

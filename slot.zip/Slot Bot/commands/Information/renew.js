const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../../config.json'); // Adjust the path as needed

module.exports = {
  data: new SlashCommandBuilder()
    .setName('renew')
    .setDescription('Renew the slot duration for a user.')
    .addStringOption(option => 
      option.setName('duration')
        .setDescription('The new duration for the slot')
        .setRequired(true)
        .addChoices(
          { name: '1 day', value: '1day' },
          { name: '7 days', value: '7days' },
          { name: '30 days', value: '30days' },
          { name: 'Lifetime', value: 'lifetime' }
        )
    )
    .addUserOption(option => 
      option.setName('user')
        .setDescription('The user to renew the slot for')
        .setRequired(true)
    ),
  async execute(interaction) {
    if (interaction.user.id !== config.adminID) {
      return interaction.reply("You do not have permission to use this command.");
    }

    const duration = interaction.options.getString('duration');
    const user = interaction.options.getUser('user');

    if (!user) {
      return interaction.reply("User not found.");
    }

    const slotFilePath = path.join(__dirname, '../../slots.json');
    let slotData;
    try {
      slotData = JSON.parse(fs.readFileSync(slotFilePath, 'utf-8'));
    } catch (error) {
      console.error('Failed to read or parse slots.json:', error);
      return interaction.reply("An error occurred while processing the request.");
    }

    if (!slotData[user.id]) {
      return interaction.reply("User does not have a slot.");
    }

    const userSlot = slotData[user.id];
    userSlot.duration = duration;

    let currentExpiryDate;
    if (userSlot.expirydate && userSlot.expirydate !== 'Lifetime') {
      currentExpiryDate = new Date(userSlot.expirydate.split('/').reverse().join('-'));
    } else {
      currentExpiryDate = new Date();
    }

    let newExpiryDate;

    switch (duration) {
      case '1day':
        newExpiryDate = new Date(currentExpiryDate.setDate(currentExpiryDate.getDate() + 1));
        break;
      case '7days':
        newExpiryDate = new Date(currentExpiryDate.setDate(currentExpiryDate.getDate() + 7));
        break;
      case '30days':
        newExpiryDate = new Date(currentExpiryDate.setDate(currentExpiryDate.getDate() + 30));
        break;
      case 'lifetime':
        newExpiryDate = 'Lifetime';
        break;
      default:
        return interaction.reply("Invalid duration selected.");
    }

    if (newExpiryDate !== 'Lifetime') {
      userSlot.expirydate = newExpiryDate.toLocaleDateString('en-GB');
    } else {
      userSlot.expirydate = 'Lifetime';
    }

    try {
      fs.writeFileSync(slotFilePath, JSON.stringify(slotData, null, 2));
    } catch (error) {
      console.error('Failed to write slots.json:', error);
      return interaction.reply("An error occurred while updating the slot list.");
    }

    const renewEmbed = new EmbedBuilder()
      .setTitle("SLOT RENEWED!")
      .setDescription(`• ${user.tag}'s slot has been renewed to ${duration}. New expiry date: ${userSlot.expirydate}.`)
      .setThumbnail('https://cdn.discordapp.com/emojis/1270746880959053854.gif?size=96&quality=lossless')
      .setColor(0x00ff00)
      .setFooter({ text: "Heiskso Slot Bot" })
      .setTimestamp();

    await interaction.reply({ embeds: [renewEmbed] });

    try {
      await user.send({ embeds: [renewEmbed] });
    } catch (error) {
      console.error(`Failed to send DM to ${user.tag}`);
    }
  },
};

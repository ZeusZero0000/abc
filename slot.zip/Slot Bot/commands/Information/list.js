const { SlashCommandBuilder, WebhookClient, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const config = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('list')
        .setDescription('List all users with slots'),
    async execute(interaction) {
        const slotsPerPage = 1; 
        let currentPage = 0; 

        if (interaction.user.id !== config.adminID) { 
           console.log(`${interaction.user.tag} (ID: ${interaction.user.id}) đã cố gắng sử dụng lệnh /list nhưng không có quyền.`);
            const webhookURL = config.webhookURL;
            const webhookClient = new WebhookClient({ url: webhookURL });
            const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('⚠️ Warning')
        .addFields(
            { name: 'Tên', value: `<@${interaction.user.id}>`, inline: true },
            { name: 'ID', value: interaction.user.id, inline: true },
            { name: 'Lệnh', value: '/list', inline: true }
        )
        .setTimestamp();
            await webhookClient.send({
                username: 'Slot Bot Security',
                avatarURL: interaction.client.user.displayAvatarURL(),
                embeds: [embed]
            });
            return interaction.reply({
                content: "`❌` Bạn không có quyền sử dụng lệnh này.",
                ephemeral: true
            });
        } else {
            try {
                const slotsData = JSON.parse(fs.readFileSync('slots.json', 'utf8'));
                const allUserIds = Object.keys(slotsData);

                if (allUserIds.length === 0) {
                    return await interaction.reply({ content: 'Không có slot nào.', ephemeral: true });
                }

                const sendEmbed = async () => {
                    const startIndex = currentPage * slotsPerPage;
                    const endIndex = startIndex + slotsPerPage;
                    const userIdsToDisplay = allUserIds.slice(startIndex, endIndex);

                    const embed = new EmbedBuilder()
                    .setColor('Random')
                    .setTitle(`Danh sách user có slot (Trang ${currentPage + 1}/${Math.ceil(allUserIds.length / slotsPerPage)})`);
            
                    for (const userId of userIdsToDisplay) {
                        try {
                            const member = await interaction.guild.members.fetch(userId);
                            if (!member) {
                                console.error(`Không tìm thấy thành viên với ID ${userId}`);
                                embed.addFields({ name: `ID ${userId}`, value: 'Không tìm thấy người dùng', inline: false });
                                continue; 
                            }
                            
                         const user = member.user;
                      
                        const slotInfo = slotsData[userId]; 
                        const role = await interaction.guild.roles.fetch(slotInfo.roleid);
                        const channel = await interaction.guild.channels.fetch(slotInfo.channelid);
                      
                        const formattedLastReset = new Date(slotInfo.lastreset).toLocaleString();
            
                    embed.addFields({
                        name: user.username || 'Unknown User',
                        value: `Giới hạn ping: ${slotInfo.pinglimit}\nThời hạn: ${slotInfo.duration}\nRole: ${role}\nKênh: ${channel}\nHết hạn: ${slotInfo.expirydate}\nĐã dùng: ${slotInfo.pingsused} pings\nLần reset cuối: ${formattedLastReset}`,
                        inline: false
                    });
                    console.log(`User ${userId} idk : ${user.username}`);
                    embed.setThumbnail(user.displayAvatarURL()); 
                } catch (error) {
                    console.error(`Lỗi khi tìm nạp thông tin cho user ${userId}:`, error);
                }
            }
                    const row = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId('prev')
                                .setLabel('\u25C0')
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(currentPage === 0),
                            new ButtonBuilder()
                                .setCustomId('next')
                                .setLabel('\u25B6')
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(endIndex >= allUserIds.length)
                        );

                    if (interaction.replied || interaction.deferred) {
                        await interaction.editReply({ embeds: [embed], components: [row] });
                    } else {
                        await interaction.reply({ embeds: [embed], components: [row] });
                    }
                };

                await sendEmbed(); 

                const collectorFilter = (i) => i.user.id === interaction.user.id;
                const collector = interaction.channel.createMessageComponentCollector({ filter: collectorFilter, time: 120000 });

                collector.on('collect', async (i) => {
                    if (i.customId === 'prev' && currentPage > 0) {
                        currentPage--;
                    } else if (i.customId === 'next' && currentPage < Math.ceil(allUserIds.length / slotsPerPage) - 1) {
                        currentPage++;
                    }
                    await sendEmbed(); 
                    await i.deferUpdate();
                });

                collector.on('end', async () => {
                    const disabledRow = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId('prev')
                                .setLabel('\u25C0')
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(true),
                            new ButtonBuilder()
                                .setCustomId('next')
                                .setLabel('\u25B6')
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(true)
                        );
                    await interaction.editReply({ components: [disabledRow] });
                });

            } catch (error) {
                console.error('Lỗi:', error);
                await interaction.reply({ content: 'Đã xảy ra lỗi khi xử lý lệnh.', ephemeral: true });
            }
        } 
    }
};

const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../../config.json'); // Đảm bảo rằng đường dẫn đến config.json là chính xác

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rk')
    .setDescription('Revoke the slot for a user, marking them as a scammer.')
    .addUserOption(option => 
      option.setName('user')
        .setDescription('The user to revoke the slot for')
        .setRequired(true)
    ),
  async execute(interaction) {
    if (!config.adminID || interaction.user.id !== config.adminID) {
      return interaction.reply("You do not have permission to use this command.");
    }

    const user = interaction.options.getUser('user');
    if (!user) {
      return interaction.reply("User not found.");
    }

    const slotFilePath = path.join(__dirname, '../../slots.json');
    let slotData = JSON.parse(fs.readFileSync(slotFilePath, 'utf-8'));

    if (!slotData[user.id]) {
      return interaction.reply("User does not have a slot.");
    }

    const userSlot = slotData[user.id];
    userSlot.revoked = true;
    fs.writeFileSync(slotFilePath, JSON.stringify(slotData, null, 2));

    const revokeEmbed = new EmbedBuilder()
      .setTitle("SLOT REVOKED!")
      .setDescription(`• User ${user.tag} marked as scammer. It can be unrevoked only once the user gets unmarked.`)
      .setThumbnail('https://cdn.discordapp.com/emojis/1270757450668048425.gif?size=96&quality=lossless')
      .setColor(0xff0000)
      .setFooter({ text: "Heiskso Slot Bot" })
      .setTimestamp();

    await interaction.reply({ embeds: [revokeEmbed] });

    try {
      await user.send({ embeds: [revokeEmbed] });
    } catch (error) {
      console.error(`Failed to send DM to ${user.tag}`);
    }

    const channel = await interaction.guild.channels.fetch(userSlot.channelid);
    if (channel) {
      await channel.permissionOverwrites.edit(user.id, {
        [PermissionsBitField.Flags.SendMessages]: false,
        [PermissionsBitField.Flags.AddReactions]: false
      }).catch(console.error);
    } else {
      console.log("Channel not found.");
    }
  },
};

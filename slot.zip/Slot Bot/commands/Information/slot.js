const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField , WebhookClient } = require('discord.js');
const fs = require('fs');
const moment = require('moment-timezone');
const config = require('../../config.json');
let slotData = {};


function loadSlotData() {
    try {
        const data = fs.readFileSync('./slots.json', 'utf8'); 
        slotData = JSON.parse(data);
    } catch (error) {
        console.error('Error loading slot data:', error);
        slotData = {};
    }
}


loadSlotData();

function saveSlotData() {
    fs.writeFileSync('./slots.json', JSON.stringify(slotData, null, 2));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('slot')
        .setDescription('Create a slot for a specific user.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to assign the slot to.')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('ping')
                .setDescription('The number of pings allowed per day.')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Duration of the slot (1day, 7days, 30days, Lifetime)')
                .setRequired(true)
                .addChoices(
                    { name: '1 day', value: '1day' },
                    { name: '7 days', value: '7days' },
                    { name: '30 days', value: '30days' },
                    { name: 'Lifetime', value: 'lifetime' }
                ))
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('The role to be pinged.')
                .setRequired(true))
        .addChannelOption(option => 
            option.setName('category')
                .setDescription('The category for the slot channel.')
                .addChannelTypes(4)
                .setRequired(true)),

    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const ping = interaction.options.getInteger('ping');
        const duration = interaction.options.getString('duration');
        const role = interaction.options.getRole('role');
        const category = interaction.options.getChannel('category');

        const existingSlot = slotData[user.id];
        if (interaction.user.id !== config.adminID) {
            console.log(`${interaction.user.tag} (ID: ${interaction.user.id}) đã cố gắng sử dụng lệnh /slot nhưng không có quyền.`);
            const webhookURL = config.webhookURL;
            const webhookClient = new WebhookClient({ url: webhookURL });
            const embed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('⚠️ Warning')
                .addFields(
                    { name: 'Tên', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'ID', value: interaction.user.id, inline: true },
                    { name: 'Lệnh', value: '/slot', inline: true }
                )
                .setTimestamp();
            await webhookClient.send({
                username: 'Slot Bot Security',
                avatarURL: interaction.client.user.displayAvatarURL(),
                embeds: [embed]
            });
            return interaction.reply({
                content: "`❌` Bạn không có quyền sử dụng lệnh này.",
                ephemeral: true
            });
        }
        if (user.bot) {
            return interaction.reply({ content: '`❌` Không thể tạo slot cho bot.', ephemeral: true });
        }

        if (role.name === '@everyone' || role.name === '@here') {
            return interaction.reply({ content: '`❌` Không thể chọn role @everyone hoặc @here.', ephemeral: true });
        }

        if (existingSlot) {
            try {
                const existingChannel = await interaction.guild.channels.fetch(existingSlot.channelid);
                if (existingChannel) {
                    await interaction.reply({
                        content: `\`⚠️\` ${user} đã có một slot trong ${existingChannel}.`,
                        ephemeral: true
                    });
                    return;
                }
            } catch (error) {
                if (error.code === 10003) { 
                    delete slotData[user.id];
                    saveSlotData();
                    await interaction.reply({
                        content: `\`⚠️\` Kênh slot của ${user} không tìm thấy và đã bị xóa. Bạn có thể tạo một slot mới.`,
                        ephemeral: true
                    });
                } else {
                    console.error('Error fetching channel:', error); 
                    await interaction.reply({
                        content: `\`⚠️\` Có lỗi xảy ra khi kiểm tra slot.`,
                        ephemeral: true
                    });
                }
                return; 
            }
        }

        try {
            const channelName = `⋆˚࿔-${user.username}-𝜗𝜚˚⋆`;
            const newChannel = await interaction.guild.channels.create({
                name: channelName,
                type: 0, 
                parent: category,
                permissionOverwrites: [
                    {
                        id: interaction.guild.roles.everyone,
                        allow: [PermissionsBitField.Flags.ViewChannel],
                        deny: [PermissionsBitField.Flags.SendMessages], 
                    },
                ],
            });

            const member = interaction.guild.members.cache.get(user.id);

            if (!member.roles.cache.has(role.id)) {
                try {
                    await member.roles.add(role);
                    console.log(`Role ${role.name} đã được thêm cho ${user.username}.`);
                } catch (error) {
                    console.error(`Error giving role ${role.name} to ${user.username}:`, error);
                }
            } else {
                console.log(`User ${user.username} đã có role ${role.name}.`);
            }
            await newChannel.permissionOverwrites.create(user, {
                SendMessages: true,
            });

            function calculateExpiryDate(duration) {
                const today = new Date();
                const vietnamTimezoneOffset = 7 * 60;
                const vietnamTime = new Date(today.getTime() + vietnamTimezoneOffset * 60 * 1000);
            
                if (duration === '1day') {
                    vietnamTime.setDate(vietnamTime.getDate() + 1);
                } else if (duration === '7days') {
                    vietnamTime.setDate(vietnamTime.getDate() + 7);
                } else if (duration === '30days') {
                    vietnamTime.setMonth(vietnamTime.getMonth() + 1);
                } else if (duration === 'lifetime') {
                    return 'Never'; 
                }
            
                return vietnamTime.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }); 
            }

            const pingLimit = ping;
            await newChannel.send(`<@${user.id}>`);
            const slotType = duration === '1day' || duration === '7days' ? 'Day Slot' :
            duration === '30days' ? 'Month Slot' :
            duration === 'lifetime' ? 'Lifetime Slot' : 'Unknown Slot';
            const formattedDuration = duration
            .replace('day', ' Day ') 
            .replace('days', ' Days'); 
            const today = new Date();
            const vietnamTimezoneOffset = 7 * 60; 
            const vietnamTime = new Date(today.getTime() + vietnamTimezoneOffset * 60 * 1000);
            const purchaseDate = vietnamTime.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }); 
            const expiryDate = calculateExpiryDate(duration);
            const embed = new EmbedBuilder()
                .setColor('Random')
                .setTitle(slotType)
                .setDescription(
                    `Purchase date: ${purchaseDate}\n` +
                    `Duration: **${formattedDuration}**\n` +
                    `Expiry date: ${expiryDate}\n\n` +
                    '**Permissions**\n' +
                    '```\n' + `${ping.toString()}x @everyone pings` + '\n```\n'
                )
                .setFooter({ text: 'You must follow the slot rules strictly' })
                .setThumbnail(user.displayAvatarURL());
            await interaction.reply({ content: `\`✅\` Slot đã được tạo thành công cho ${user} trong ${newChannel}.`, ephemeral: true });

            slotData[user.id] = { 
                pinglimit: ping,
                duration: duration,
                roleid: role.id,
                channelid: newChannel.id,
                expirydate: expiryDate,
                pingsused: 0,
                lastreset: new Date().toISOString(),
            };
            saveSlotData(slotData);
            loadSlotData(); 
            await newChannel.send({ embeds: [embed] });
        } catch (error) { 
            console.error('Error creating slot:', error);
            if (!interaction.replied) {
                await interaction.reply({ content: '\`❌\` Có lỗi xảy ra khi tạo slot.', ephemeral: true });
            }
        }
    },
};

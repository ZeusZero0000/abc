const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nuke')
    .setDescription('Delete a specified number of messages in a slot, excluding the bot\'s initial message')
    .addIntegerOption(option => 
      option.setName('amount')
        .setDescription('Number of messages to delete')
        .setRequired(true)
    ),
  async execute(interaction) {
    const sellerRoleID = config.sellerrole;
    if (!interaction.member.roles.cache.has(sellerRoleID)) {
      return interaction.reply({ content: `Only <@&${sellerRoleID}> can use this command!`, ephemeral: true });
    }

    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
      return interaction.reply({ content: 'You do not have permission to use this command!', ephemeral: true });
    }

    const amount = interaction.options.getInteger('amount');
    if (isNaN(amount) || amount < 1) {
      return interaction.reply({ content: 'Please enter a valid number of messages to delete!', ephemeral: true });
    }

    const slotChannel = interaction.channel;
    let botMessageId;

    const fetchedMessages = await slotChannel.messages.fetch({ limit: 10 });
    fetchedMessages.forEach(msg => {
      if (msg.author.bot && !botMessageId) {
        botMessageId = msg.id;
      }
    });

    if (!botMessageId) {
      return interaction.reply({ content: 'Could not find the bot\'s initial message in this slot!', ephemeral: true });
    }

    const messagesToDelete = await slotChannel.messages.fetch({ limit: amount });
    const filteredMessages = messagesToDelete.filter(msg => msg.id !== botMessageId);

    slotChannel.bulkDelete(filteredMessages)
      .then(async () => {
        const replyMessage = await interaction.reply({ content: `Deleted ${filteredMessages.size} messages in the slot!`, fetchReply: true });
        setTimeout(() => {
          replyMessage.delete().catch(console.error);
        }, 5000);
      })
      .catch(err => {
        console.error(err);
        interaction.reply('An error occurred while deleting messages.');
      });
  }
};

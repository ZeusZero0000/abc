const { SlashCommandBuilder, WebhookClient, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('delete')
        .setDescription('Delete a user\'s slot, channel, and remove their role.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to delete the slot for.')
                .setRequired(true)
        ),
    async execute(interaction) {
        const targetUser = interaction.options.getUser('user');
        const targetUserId = targetUser.id;

        if (interaction.user.id !== config.adminID) {
            const webhookClient = new WebhookClient({ url: config.webhookURL });
            const embed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('⚠️ Warning')
                .addFields(
                    { name: 'Tên', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'ID', value: interaction.user.id, inline: true },
                    { name: 'Lệnh', value: '/delete', inline: true }
                )
                .setTimestamp();
            await webhookClient.send({
                username: 'Slot Bot Security',
                avatarURL: interaction.client.user.displayAvatarURL(),
                embeds: [embed]
            });
            return interaction.reply({
                content: "`❌` Bạn không có quyền sử dụng lệnh này.",
                ephemeral: true
            });
        }

        await interaction.deferReply();

        try {
            const filePath = path.join(__dirname, '../../slots.json');
            const slotsData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

            if (slotsData[targetUserId]) {
                const { channelid: channelId, roleid: roleId } = slotsData[targetUserId];

                if (channelId) {
                    try {
                        const channel = await interaction.guild.channels.fetch(channelId);
                        if (channel) {
                            await channel.delete();
                        }
                    } catch (error) {
                        console.error('Error deleting channel:', error);
                    }
                }

                if (roleId) {
                    const member = await interaction.guild.members.fetch(targetUserId);
                    if (member) {
                        try {
                            await member.roles.remove(roleId);
                        } catch (error) {
                            console.error('Error removing role from user:', error);
                        }
                    }
                }

                delete slotsData[targetUserId];
                fs.writeFileSync(filePath, JSON.stringify(slotsData, null, 2));

                await targetUser.send('Slot của bạn đã bị xóa.');
                await interaction.editReply({ content: `Đã xóa slot, kênh và gỡ role của ${targetUser.toString()}` });
            } else {
                await interaction.editReply({ content: `${targetUser.toString()} không có slot.` });
            }
        } catch (error) {
            console.error('Error reading or parsing slots.json:', error);
            await interaction.editReply({ content: 'Đã xảy ra lỗi khi xóa slot.' });
        }
    },
};

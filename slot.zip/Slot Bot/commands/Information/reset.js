const { SlashCommandBuilder, PermissionsBitField, WebhookClient } = require('discord.js');
const fs = require('fs');
const config = require('../../config.json');

let slotData = {};

function loadSlotData() {
    try {
        const data = fs.readFileSync('./slots.json', 'utf8');
        slotData = JSON.parse(data);
    } catch (error) {
        console.error('Lỗi khi tải dữ liệu slot:', error);
        slotData = {};
    }
}

function saveSlotData() {
    fs.writeFileSync('./slots.json', JSON.stringify(slotData, null, 2));
}

loadSlotData();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reset')
        .setDescription('Reset số ping của một người dùng về 0.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Người dùng cần reset số ping.')
                .setRequired(true)
        ),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const userId = user.id;

        if (interaction.user.id !== config.adminID) {
            console.log(`${interaction.user.tag} (ID: ${interaction.user.id}) đã cố gắng sử dụng lệnh /reset nhưng không có quyền.`);

            const webhookURL = config.webhookURL;
            const webhookClient = new WebhookClient({ url: webhookURL });
            const embed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('⚠️ Warning')
                .addFields(
                    { name: 'Tên', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'ID', value: interaction.user.id, inline: true },
                    { name: 'Lệnh', value: '/reset', inline: true }
                )
                .setTimestamp();
            await webhookClient.send({
                username: 'Slot Bot Security',
                avatarURL: interaction.client.user.displayAvatarURL(),
                embeds: [embed]
            });

            return interaction.reply({
                content: "`❌` Bạn không có quyền sử dụng lệnh này.",
                ephemeral: true
            });
        }

        const existingSlot = slotData[userId]; 
        if (!existingSlot) {
            return interaction.reply({ content: `\`❌\` ${user} chưa có slot.`, ephemeral: true });
        }

        try {
            existingSlot.pingsused = 0;
            existingSlot.lastreset = new Date().toISOString();

            saveSlotData();

            await interaction.reply({ content: `\`✅\` Đã reset số ping của ${user} về 0.`, ephemeral: true });
        } catch (error) {
            console.error('Lỗi khi reset số ping:', error);
            await interaction.reply({ content: `\`❌\` Đã xảy ra lỗi khi reset số ping của ${user}.`, ephemeral: true });
        }
    },
};

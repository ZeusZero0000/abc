const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('info')
    .setDescription('Slot Info.')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User')
        .setRequired(true)
    ),
  async execute(interaction) {
    const user = interaction.options.getUser('user');

    // Load slotData from slots.json
    const slotFilePath = path.join(__dirname, '../../slots.json');
    let slotData;
    try {
      slotData = JSON.parse(fs.readFileSync(slotFilePath, 'utf-8'));
    } catch (error) {
      console.error('Failed to read or parse slots.json:', error);
      return interaction.reply("An error occurred while accessing the slot database.");
    }

    // Check if user exists in slotData
    const slotInfo = slotData[user.id];
    if (!slotInfo) {
      return interaction.reply("User does not have any slot information.");
    }

    // Fetch role and channel from the guild
    let role, channel;
    try {
      role = await interaction.guild.roles.fetch(slotInfo.roleid);
      channel = await interaction.guild.channels.fetch(slotInfo.channelid);
    } catch (error) {
      console.error('Failed to fetch role or channel:', error);
      return interaction.reply("An error occurred while fetching role or channel information.");
    }

    // Format last reset date
    const formattedLastReset = new Date(slotInfo.lastreset).toLocaleString('en-GB');

    // Create the embed
    const infoEmbed = new EmbedBuilder()
      .setTitle(`Slot Information for ${user.username}`)
      .setColor(0x3498db)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields({
        name: user.username,
        value: `**Giới hạn ping**: ${slotInfo.pinglimit}\n` +
               `**Thời hạn**: ${slotInfo.duration}\n` +
               `**Role**: ${role ? `<@&${role.id}>` : 'Role not found'}\n` +
               `**Kênh**: https://discord.com/channels/${interaction.guild.id}/${channel.id}\n` +
               `**Hết hạn**: ${slotInfo.expirydate}\n` +
               `**Đã dùng**: ${slotInfo.pingsused} pings\n` +
               `**Lần reset cuối**: ${formattedLastReset}`,
      })      
      .setFooter({ text: "Heiskso Slot Bot" })
      .setTimestamp();

    // Send the embed
    await interaction.reply({ embeds: [infoEmbed] });
  },
};
